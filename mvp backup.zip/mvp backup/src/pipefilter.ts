import { Component } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';

export class PipeFilterComponent {
filter = 'everything';


}
