import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { AddUser } from './adduser';

@Injectable()
export class SampleserviceService {
  static userDetails: any;
  static registerDetails: any;
  static newsDetails: any;
  static response: any;
  static res: any;
  private _url: string = 'http://localhost:8080/newspaper/rest/user/auth';
  public _loginUrl: string = 'http://localhost:8080/newspaper/rest/user/authendication';
  public _registerUrl: string = 'http://localhost:8080/newspaper/rest/user/signup';
  public newsuploadUrl: string = 'http://localhost:8080/newspaper/rest/user/add';
  constructor(private http: Http) { }
  getData() {
    return this.http.get(this._url)
    .map((response: Response) => response.json());
  }
  loginSubmit(loginData) {
    const url = `${this._loginUrl}/${loginData.email}/${loginData.password}`;
    return this .http.post(url, JSON.stringify({ email: loginData.email, password: loginData.password }))
    .map((response: Response) => {
  SampleserviceService.userDetails = response.json(),
      console.log(SampleserviceService.userDetails);
    });
}
registerSubmit(registerData) {
  const url = `${this._registerUrl}/${registerData.name}/${registerData.email}/${registerData.password}`;
  return this .http.post(url, JSON.stringify({ name: registerData.name, email: registerData.email, password: registerData.password }))
  .map((res: Response) => {
SampleserviceService.registerDetails = res.json(),
    console.log(SampleserviceService.registerDetails);
  });
}

newsUpload(newsupload) {
  const url = `${this.newsuploadUrl}/${newsupload.title}
  /${newsupload.description}/${newsupload.fullstory}/${newsupload.news}/${newsupload.date}`;

  return this .http.post(url, JSON.stringify({title: newsupload.title, description: newsupload.description,
    fullstory: newsupload.fullstory, news: newsupload.news, date: newsupload.date }))
  .map((res: Response) => {
SampleserviceService.newsDetails = res.json(),
    console.log(SampleserviceService.newsDetails);
  });
}
}

