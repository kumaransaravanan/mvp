import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';

@Component({
  selector: 'app-sportsnews',
  templateUrl: './sportsnews.component.html',
  styleUrls: ['./sportsnews.component.css']
})
export class SportsnewsComponent implements OnInit {

  constructor(private sampleservice: SampleserviceService) { }
  news = [];
  ngOnInit() {
    this.sampleservice.getData()
    .subscribe((resData) => {
      this.news = resData;
    });
  }
}
