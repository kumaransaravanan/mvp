import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { SampleserviceService } from '../sampleservice.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  constructor(private sampleservice: SampleserviceService, private route: Router) { }
  ngOnInit() {
  }
  registerSubmit(registerData) {
    console.log(registerData);
  this.sampleservice.newsUpload(registerData).subscribe(
            data => {
           console.log('success');

         },
         err => {
           console.log('failed');
         }
  );
}
}
