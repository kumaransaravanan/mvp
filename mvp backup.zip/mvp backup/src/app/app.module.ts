import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { WorldnewsComponent } from './worldnews/worldnews.component';
import { GeneralnewsComponent } from './generalnews/generalnews.component';
import { routingComponents } from './app-routing.module';
import { SportsnewsComponent } from './sportsnews/sportsnews.component';
import { EntertainmentnewsComponent } from './entertainmentnews/entertainmentnews.component';
import { PoliticsnewsComponent } from './politicsnews/politicsnews.component';
import { BusinessnewsComponent } from './businessnews/businessnews.component';
import { HttpModule } from '@angular/http';
import { SampleserviceService } from './sampleservice.service';
import { FilterPipe } from './filter.pipe';
import { IndexComponent } from './index/index.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NewsuploadComponent } from './newsupload/newsupload.component';
import { OrderbyPipe } from './orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    WorldnewsComponent,
    GeneralnewsComponent,
    routingComponents,
    SportsnewsComponent,
    EntertainmentnewsComponent,
    PoliticsnewsComponent,
    BusinessnewsComponent,
    FilterPipe,
    IndexComponent,
    LoginComponent,
    RegisterComponent,
    NewsuploadComponent,
    OrderbyPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule
  ],
  providers: [SampleserviceService, FilterPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }

