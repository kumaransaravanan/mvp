import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';

@Component({
  selector: 'app-entertainmentnews',
  templateUrl: './entertainmentnews.component.html',
  styleUrls: ['./entertainmentnews.component.css']
})
export class EntertainmentnewsComponent implements OnInit {

  constructor(private sampleservice: SampleserviceService) { }
  news = [];
  ngOnInit() {
    this.sampleservice.getData()
    .subscribe((resData) => {
      this.news = resData;
    });
  }
}
