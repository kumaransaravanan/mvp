import { Component } from '@angular/core';
import { GeneralnewsComponent } from './generalnews/generalnews.component';
import { Pipe, PipeTransform } from '@angular/core';
import { SampleserviceService } from './sampleservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {
}
