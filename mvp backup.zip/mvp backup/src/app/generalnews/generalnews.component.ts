import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';
import { FilterPipe } from '../filter.pipe';
import { Pipe, PipeTransform } from '@angular/core';
@Component({
  selector: 'app-generalnews',
  templateUrl: './generalnews.component.html',
  styleUrls: ['./generalnews.component.css'],
})

export class GeneralnewsComponent implements OnInit {

  constructor(private sampleservice: SampleserviceService) { }
   news = [];
  ngOnInit() {
    console.log('---------------ngonit initialize------------');
    this.sampleservice.getData()
    .subscribe((resData) => {
      this.news = resData;
      console.log(JSON.stringify(resData));
    });
  }
}
