import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WorldnewsComponent } from './worldnews/worldnews.component';
import { SportsnewsComponent } from './sportsnews/sportsnews.component';
import { PoliticsnewsComponent } from './politicsnews/politicsnews.component';
import { EntertainmentnewsComponent } from './entertainmentnews/entertainmentnews.component';
import { BusinessnewsComponent } from './businessnews/businessnews.component';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent} from './register/register.component';

const routes: Routes = [
  {path: '',
  pathMatch: 'full',
  component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'index', component: IndexComponent,
children: [
  {path: 'worldnews', component: WorldnewsComponent},
  {path: 'sportsnews', component: SportsnewsComponent},
  {path: 'businessnews', component: BusinessnewsComponent},
  {path: 'entertainmentnews', component:  EntertainmentnewsComponent},
  {path: 'politicsnews', component: PoliticsnewsComponent}
]},
  // {path: 'worldnews', component: WorldnewsComponent},
  // {path: 'sportsnews', component: SportsnewsComponent},
  // {path: 'businessnews', component: BusinessnewsComponent},
  // {path: 'entertainmentnews', component: EntertainmentnewsComponent},
  // {path: 'politicsnews', component: PoliticsnewsComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
export const routingComponents = [WorldnewsComponent];
