import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  constructor(private router: Router, private activateroute: ActivatedRoute ) { }

  ngOnInit() {
  }
  World() {
  this.router.navigate(['worldnews'], { relativeTo: this.activateroute});
  }
  Sports() {
  this.router.navigate(['sportsnews'], { relativeTo: this.activateroute});
  }
  Business() {
  this.router.navigate(['businessnews'], { relativeTo: this.activateroute});
  }
  Entertainment() {
  this.router.navigate(['entertainmentnews'], { relativeTo: this.activateroute});
  }
  Politics() {
  this.router.navigate(['politicsnews'], { relativeTo: this.activateroute});
  }
  submit(newsdate){
    
  }
}
