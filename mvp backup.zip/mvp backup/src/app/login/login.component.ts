import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { SampleserviceService } from '../sampleservice.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  credentials = { email : '', password : ''};
  constructor(private sampleservice: SampleserviceService, private route: Router) { }
  public router;
  ngOnInit() {
  }
  loginSubmit(loginData) {
    console.log(loginData);
  this.sampleservice.loginSubmit(loginData).subscribe(
         data => {
           console.log('success');
           this.route.navigate(['/index']);
         },
         err => {
           console.log('failed');
         }
  );
}
}









