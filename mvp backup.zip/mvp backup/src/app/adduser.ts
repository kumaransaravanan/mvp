export class AddUser {
  name: string;
  email: string;
  password: string;
  constructor() { }
}
