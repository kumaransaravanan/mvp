import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';

@Component({
  selector: 'app-worldnews',
  templateUrl: './worldnews.component.html',
  styleUrls: ['./worldnews.component.css']
})
export class WorldnewsComponent implements OnInit {
  constructor(private sampleservice: SampleserviceService) { }
  news = [];
  ngOnInit() {
    this.sampleservice.getData()
    .subscribe((resData) => {
      this.news = resData;
    });
  }
}

