import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { SampleserviceService } from '../sampleservice.service';

@Component({
  selector: 'app-newsupload',
  templateUrl: './newsupload.component.html',
  styleUrls: ['./newsupload.component.css']
})
export class NewsuploadComponent implements OnInit {
  credentials = { date : '', news : '', title : '', description : '', fullstory : ''};
  news = [
    {name: "World"},
    {name: "Sports"},
    {name: "Business"},
    {name: "Entertainment"},
    {name: "Politics"}
  ];
  constructor(private sampleservice: SampleserviceService, private route: Router) { }

  ngOnInit() {
  }
  newsUpload(newsupload) {
    console.log(newsupload);
  this.sampleservice.newsUpload(newsupload).subscribe(
            data => {
           console.log('success');
         },
         err => {
           console.log('failed');
         }
  );
}
}


