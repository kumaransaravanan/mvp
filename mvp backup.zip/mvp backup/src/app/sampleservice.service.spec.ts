import { TestBed, inject } from '@angular/core/testing';

import { SampleserviceService } from './sampleservice.service';

describe('SampleserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SampleserviceService]
    });
  });

  it('should be created', inject([SampleserviceService], (service: SampleserviceService) => {
    expect(service).toBeTruthy();
  }));
});
