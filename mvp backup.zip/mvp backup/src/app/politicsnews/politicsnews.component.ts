import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';

@Component({
  selector: 'app-politicsnews',
  templateUrl: './politicsnews.component.html',
  styleUrls: ['./politicsnews.component.css']
})
export class PoliticsnewsComponent implements OnInit {

  constructor(private sampleservice: SampleserviceService) { }
  news = [];
  ngOnInit() {
    this.sampleservice.getData()
    .subscribe((resData) => {
      this.news = resData;
    });
  }
}
